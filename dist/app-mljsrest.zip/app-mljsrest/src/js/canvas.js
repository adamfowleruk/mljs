
document.write(
  "  
      <div class=""header"" arcsize=""5 5 0 0"">
        V6+: 
        <a href=""search.html"">Search</a> | 
        <a href=""snippets.html"">Search with Snippets</a> | 
        <a href=""charts.html"">Charts</a> | 
        <a href=""chartsearch.html"">Chart + Search</a> | 
        <a href=""movies.html"">Co-occurence</a> | 
        <a href=""error.html"">Error</a> | 
        <a href=""kratu.html"">Kratu</a>  |
        <a href=""upload.html"">Upload</a> |
        <a href=""docview.html"">View Doc</a> |
        <a href=""openlayers.html"">Maps</a> |
        <a href=""tagcloud.html"">Tag Cloud</a>
        <br/>
      V7+:
        <a href=""sparqlbar.html"">Semantic (SPARQL) Search</a> | 
        <a href=""explorer.html"">Explorer</a> 
        <br/>
      REST Extensions:  
        <a href=""rdb2rdf.html"">RDB2RDF</a> 
        <br/>
      In Development:  
        <a href=""docbuilder.html"">Document Builder</a> | 
        <a href=""workplace.html"">Workplace</a> | 
        <a href=""collectionuris.html"">Collection URIs</a> | 
        <a href=""dnd.html"">Drag &amp; Drop</a>
      </div>"
  );
  