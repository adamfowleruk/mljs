// global variable definitions
com = window.com || {};
com.marklogic = window.com.marklogic || {};
com.marklogic.widgets = window.com.marklogic.widgets || {};

// SEARCH RESULTS DECLARE ALL WIDGET









// LIST RM COLLECTIONS WIDGET -> NA Same as any collection widget - widget-collections.js








// VIEW RM COLLECTION WIDGET -> NA Instead use search widget with constraint on collection URI as it's more flexible









// LIST RM RETENTION RULES WIDGET











// ADD RM RETENTION RULES WIDGET

