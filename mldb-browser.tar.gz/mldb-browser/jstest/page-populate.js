
$(document).ready(function() {
  // initialise MLDB
  var db = new mldb(); // calls default configure
  
  // save then get doc
  var docs = [
    {title: "Polly the Penguin", summary: "Penguins are awesome", animal: "penguin", family: "bird"},
    {title: "Olly the Ostrich", summary: "Tasty and lean", animal: "ostrich", family: "bird"},
    {title: "Percy the Pigeon", summary: "Flying rats", animal: "pigeon", family: "bird"},
    {title: "Dave the MarkLogician", summary: "Sir Dave of Vanguard", animal: "homosapien", family: "marklogician"},
    {title: "Eric the MarkLogician", summary: "Sir Eric of the Community", animal: "homosapien", family: "marklogician"},
    {title: "Dilbert the Dog", summary: "Dogs are cool", animal: "dog", family: "pet"},
    {title: "Charlie the Cat", summary: "Cats are boring", animal: "cat", family: "pet"},
    {title: "Roger the Rat", summary: "Plague carriers", animal: "rat", family: "pet"},
    {title: "Hammy the Hamster", summary: "Do dah dee dee do dah do do", animal: "hamster", family: "pet"},
    {title: "George the Gerbil", summary: "Tiny", animal: "gerbil", family: "pet"},
    {title: "Chirpy the Chicken", summary: "Thinks she's human", animal: "chicken", family: "pet"},
    {title: "Charlie the Cat", summary: "Only live a couple of years", animal: "guinea pig", family: "pet"},
    {title: "Adam the MarkLogician", summary: "Adam has no imagination", animal: "homosapien", family: "marklogician"}
  ];
  
  for (var i = 0;i < docs.length;i++) {
    db.save(docs[i],"/animals/" + i,{collection: "animals"}, function(result) {
      // do something
    });
  }
});